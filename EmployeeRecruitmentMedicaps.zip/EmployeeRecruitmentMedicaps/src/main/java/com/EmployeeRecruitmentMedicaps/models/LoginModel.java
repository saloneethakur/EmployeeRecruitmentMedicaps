package com.EmployeeRecruitmentMedicaps.models;

public class LoginModel {

	private String email;
	private String password;
}
