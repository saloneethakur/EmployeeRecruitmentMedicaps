package com.EmployeeRecruitmentMedicaps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRecruitmentMedicapsApplicationTests {

	@Test
	void contextLoads() {
	}

}
